﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[RequireComponent(typeof(Rigidbody))]
public class MoveController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float sensitivity = 1f;
    public Transform camera;
    Vector3 direction;
    Rigidbody myRigidbody;
    // Start is called before the first frame update
    void Start()
    {
        myRigidbody = GetComponent<Rigidbody>();
    }
    // Update is called once per frame
    void Update()
    {
        Vector3 moveInput = new Vector3(camera.forward.x * Input.GetAxisRaw("Horizontal"), 0, camera.forward.z * Input.GetAxisRaw("Vertical"));
        direction = camera.forward * Input.GetAxisRaw("Vertical") + camera.right * Input.GetAxisRaw("Horizontal");
        transform.localEulerAngles = new Vector3(0f, camera.rotation.eulerAngles.y, 0f);
    }
    public void FixedUpdate()
    {
        myRigidbody.MovePosition(myRigidbody.position + direction.normalized * moveSpeed * Time.fixedDeltaTime);
        if (Input.GetKeyDown(KeyCode.Space)) myRigidbody.AddForce(transform.up * 500);
    }
}